In this folder there are the following files 
1-Project1.java -- this is the main program  
2-mem.java -- this is the memory program 
3- sample1.txt
4- sample2.txt
5- sample3.txt
6- sample4.txt 
7- sample5.txt 
8- Summary 
9- README 

BEFORE LAUNCHING THE PROGRAM 
1- compile javac Project1.java 
2- compile javac mem.java 

LAUNCHING THE PROGRAM 
use the following command: java <project1> <filename> <timer number>
example: 

java Project1 sample1.txt 50

PS:  you will notice that after running the program there will be a log.txt file create
I used that file for memory debugging purpose. I taught it was cool so I left it in the code 
fell free to look at it and tell me what you think. If you've read this far, know that you 
are awesome.  
